This directory contains some files that have been encrypted with ansible-vault.

This is to test out the decrypt parameter in win_copy.

The password is: password
