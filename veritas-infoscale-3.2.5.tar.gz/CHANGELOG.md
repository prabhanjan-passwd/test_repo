# Changelog
All notable changes to this project will be documented in this file.

## [v3.2.5] - 2024-09-16
MD5 - e7e460c1fdfb2f6e4082b310ad5c88dd 

### Added
- IIP-43944 Added autostart services option for patchupgrade

### Changes
- IIP-43942 Updated release matrix

### Fixed
- IIP-43973 Support for 2200 patch on IS 8.0.2
- IIP-43987 Support for 3300 patch on IS 8.0


## [v3.2.4] - 2024-06-14
MD5 - 0303159645ddae6d98a03b76c7d209fd


### Added
- IIP- 43033 Need to add ClearClone and ScanDisks attributes fs resource 

### Changes
- IIP-43366 Updated Release matrix

### Fixed
- STESC-8835 Unable To Create Volume Using Veritas Ansible Module (3.2.3)
- STESC-8747 Add an option to FSresource module to not start it after creation
- IIP-43064 Fix for ignore_kernel_version attribute


## [v3.2.3] - 2024-04-10
MD5 -  bbb811d9c43ab0b13cce49669f1bfc0f

### Added
- IIP-42494 Added ignore-kernel-check support for Patchupgarde
- IIP-42462 [BNP] Import DG containing replicated SRDF Metro Luns (create_fsresource.yml)

### Changes
- IIP-42590 Updated Release matrix

### Fixed
- IIP-42526 Added installed product recheck for start/stop services
- IIP-42551 Fix to support multiple versions of RPM names


## [v3.2.2] - 2024-03-01
MD5 -  3cc7492b77152a0b89c8120e7b7ca4ce

### Added
- IIP-42450 Provided support for SRDF Metro replicated luns in create_dg_vol.yml playbook

### Changes
- IIP-42449 Updated Release matrix

### Fixed
- IIP-42451 Handled VRTSsfmh pkg for patchid check
- IIP-42453 Fixed Sort object creation in facter.py does not pass the argument


## [3.2.1] - [2024-01-29]
MD5 -8183f4909db5360aee88afb0c2d39450
 
### Added
- IIP-42354 Added kernel bypass check for InfoScale installation 
 
### Changes
- IIP-42344 Updated release matrix
 
### Fixed
- IIP-42355 Fixed installation failure on RHEL 9.2 due to absence of VRTSspt package
 
### Other
- None


## [3.2.0] - [2023-12-06]
MD5 - 91721a383a030a3861ea23912e810df1

### Added
- IIP-42115 Raw DG VOl resource creation

### Changes
- IIP-42212 Updated Release Matrix

### Fixed
- IIP-41977 Fixed SF config for FOUNDATION

### Other
- None


## [3.1.3] - [2023-11-09]
MD5 - cf4db99b3a220b2ad5e985033d4a94cb
 
### Added
- None
 
### Changes
- IIP-42093 Updated release matrix
 
### Fixed
- IIP-41929 Fixed vcs clusterid when input is provided from the component configuration playbooks
 
### Other
- IIP-41886 EO Logging fixes for upgrades 


## [3.1.2] - 2023-10-03
MD5 - 9ce12534835ec113d02d7e59df1ce223

### Added
- None

### Changes
- IIP-41927 Updated release matrix

### Fixed
- None

### Other
- None


## [3.1.1] - 2023-09-06
MD5 - 655a5aa6df76c3d1b55b266b308e209

### Added
- None

### Changes
- IIP-41863 Updated release matrix

### Fixed
- IIP-41046 EO Logging fixes for file permissions

### Other
- IIP-41497 Register IS hosts to VIOM management server code refactor (undocumented)


## [3.1.0] - 2023-08-01
MD5 - cd0aa6684711bd592e9144ff4da37f3c 

### Added
- IIP-41505 Full Upgrade support on SLES 15 SP3/SP4 platform
- IIP-41658 Rolling Upgrade support on SLES 15 SP3/SP4 platform
- IIP-41497 Registration of InfoScale hosts to VIOM management server from 8.0.2 and onwards (configurations, start and stop services, full and rolling upgrade)

### Changes
- IIP-41636 Updated Release matrix

### Fixed
- IIP-41480 Fixed SFCFS configuration failure
- IIP-41498 Fixed uninstallation failure on SLES 15 platform due to VRTSveki failed to uninstall
- IIP-41724 Resolved python exception and provided appropriate message that Rolling Upgrade is not supported for SF component configuration
- IIP-41516 Fixed Full and Rolling Upgrade (VCS Configuration ENTERPRISE) issue from 7.4.2/8.0 to 8.0.2 
- IIP-41725 Fixed SFCFSHA configuration failure for InfoScale 8.0
- IIP-40986 Fixed 8.0 GA with latest patch SFCFSHA configuration failure 
- IIP-41495 Fixed InfoScale 7.4.1 SF configuration 
- IIP-41496 Fixed InfoScale 7.4.1 SFCFSHA LLT/UDP configuration failure 

### Others
- None


## [3.0.0] - 2023-06-28
MD5 - 92f8aad1c0b2da8f3a658ed2d8543452 

### Added
- Etrack: 4118137 InfoScale 7.4.2, 8.0, 8.0.2 support on SLES 15 SP3/SP4 
- Support for InfoScale 8.0.2 (INDUS)
- IIP-40737 Support fsdedupschd, vxfs_replication, vxfstaskd services

### Changed
- ISAM-1802 deport and then import Disk Group after creating it (create_dg_vol.yml)
- IIP-33825 Handled mounted file systems for stop services, full upgrade, rolling upgrade, patch upgrade, component reconfiguration, uninstallation
- ISAM-1755 Secondary VIP is optional for deleting secondary site during unconfiguration of VVR
- ISAM-1828 Maintaining idempotency of vvrresource.yml playbook
- ISAM-1966 Support seednode for change_replication_state.yml
- ISAM-1976 Updated vvrresource_config module for SFHA component configuration
- ISAM-1768 Hacli function to execute command using hacli
- ISAM-1992 Implement retry mechanism for VVR operations (vradmin commands) 
- ISAM-1768 Fixed Startrep Fails with more then one RVG
- IIP-41021 Added cfscluster config command instead of creating CVM group statically (SFCFSHA/SFCFS)
- ISAM-1975 Enable/Disable hacli before running the command in the environment where Hacli is disabled
- ISAM-2021 Updated secure cluster module to use hacli function
- IIP-41335 IP/FQDN seednode support for fencing-cps playbook

### Fixed
- IIP-41348 Fixed seednode support for stop_service.yml playbook and fixed issue for bonded NIC setup for SFHA configuration (Customer Escalation)
- IIP-41167 Patchupgrade fix by making the playbook idempotent and by removing product_version parameter(Customer Escalation)
- IIP-41168 Fixed check_disk_space function by checking other directories apart from only root's space (Customer Escalation)
- ISAM-1742 Unconfigure replication: Handled dependency of SGs to be unlinked via vvrresource.yml
- ISAM-1978 Delete rlink on primary site during unconfiguration of VVR 
- ISAM-2031, ISAM-2031  Fix for delete srlvol when dco is associated to it and maintaining its idempotency
- ISAM-2065 Delete rlink when unable to add secondary and primary already exists (vvrresource.yml)
- IIP-41135 Full upgrade fix from 8.0 to 8.0.2
- ISAM-1987 VVR configuration fix as eval was not able to recognize null in json string
- IIP-41333 Fixed VCS configuration with AVAILABILITY license for ERROR VCS startup failed to run
- IIP-41332 Fixed python exception for SF Configuration

### Others
- Add support of sles for automated release matrix update


## [2.11.0] - 2023-05-06
MD5 - 47c15f33b4ad1e47e2a66228b725dd4f

### Added
- IIP-40394 Blocked perpetual license key deployments from InfoScale 8.0.2 onwards
- ISAM-1437 Multiple RVG and diskgroup support for change_replication_state.yml playbook
- ISAM-575 Plumb VIP for on-premise machines

### Changed
- ISAM-1641 Updated unconfiguration of VVR for deletion of rvg_sg_name, mount_sg_name, logownergrp_sg_name if provided
- ISAM-1440 Improvised SFCFSHA configuration execution time by removing start and stop vcs while disabling fencing
- ISAM-1385 Remove dependency on disks parameter when diskgroup already exists for create_dg_vol.yml
- ISAM-1463 VVR configuration - used vxsnap command for data volumes 
- ISAM-1397, ISAM-1410 Support FQDN/IP for seednode in create_dg_vol.yml playbook 
- ISAM-1465 Skip disks parameter if given disk is already added in disk group previously for adddisk.yml playbook
- ISAM-1484 Updated module for identifying the EC2 
- Updated release matrix

### Fixed
- IIP-40970 Fixed rolling_upgrade.yml playbook which failed due to error encapsulated bootdisk upgrade requires a reboot
- ISAM-1526 Used common function for systemctl start/stop process
- IIP-41055 Seggrated EO Logging for SF, VCS, SFCFSHA/SFHA/SFCFS
- ISAM-1455 VVR fixes for separate creation for primary and secondary site
- ISAM-1588 SFCFSHA configuration fix for IS 7.4.1 (vxconfigd should to started before vxdmp followed by vxio, vxspec)
- ISAM-1453 Fixed cluster configuration failure post executing set_tunables.yml playbook
- ISAM-1558 Skip OS disk for DiskInit module
- ISAM-1602 Fixed issue for across AZ in AWS for routing for 4 node cluster
- ISAM-1601 ISAM-1624 SFCFSHA configuration and routing fix across AZ on RHEL 7 platform (AWS)
- ISAM-1483 Fix for handling nic speed exception

### Others
- ISAM-1466 ISAM-1464 Added msg on non-seednode for create_dg_vol and add_disks playbook
- ISAM-318 Making path as absolute to the script name for automated release matrix update


## [2.10.0] - 2023-03-31
MD5 - fd28693f80d81a131cdc7c0f10cc6250

### Added
- ISAM-158 Unconfigure Replication (VVR) using vvrresource.yml playbook (can also be used to delete primary and then secondary site separately)

### Changed
- ISAM-889 Support FQDN/IP for system in route_config.yml playbook
- ISAM-497 Support multiple DG creation (more than 9)
- Updated Release matrix

### Fixed
- STESC-7872 Fixed VVR configuration when agentinfo provided is null in vvrresource.yml playbook
- IIP-40738 Updated VRTSvxfs oslibs prerequisites for InfoScale 8.0.2 on RHEL 8 and RHEL 9 platform
- ISAM-848 Fixed Facters for cnfs/cifs configuration information
- ISAM-927 Fixed Facters for host interface information by removing dependancy on ifconfig
- ISAM-1302 Fixed services not coming online after reboot

### Other
- ISAM-318 Automate release matrix download from sort


## [2.9.0] - 2023-03-01
MD5 - dfc9e6c72c460d03816e82c73bd9551c

### Added
- ISAM-578 Added preonline trigger for logownergrp service group to come online on master
- ISAM-142, ISAM-157, ISAM-939 Playbook to change replication status to start/stop/pause/resume
- ISAM-526, ISAM-939 Using VVR playbook for separate VVR configuration for secondary/primary site individually

### Changed
- IIP-40638 Resolved race condition observed between disk initialization and DG creation
- ISAM-528 Added multinode LLT/VM/FS and clusterwide VM tunable support to set_tunables.yml Playbook
- IIP-40919 Updated Release matrix

### Fixed
- ISAM-491 Fixed fencing related information fetched in Facters and move them inside fencing
 IIP-40642 Fixed SF configuration failure for product FOUNDATION installed
- ISAM-490 Fixed llt and gab related information fetch issues in Facters 

### Others
- None


## [2.8.1] - 2023-02-01
MD5 - 5586fe45f901525123e66ac35e27edb0

### Added
- IIP-40408 Added support for non-master as seednode for VVR playbook
- ISAM-470 Playbook for Add and Remove disks from diskgroup

### Changed
- IIP-40425 Removed dependency on netadrr module for LLT/UDP configuration
- ISAM-579 Setting Critical as 1 for all VVR resources in VVR playbook
- ISAM-571 Added support for IP/FQDN for seednode in VVR playbook
- IIP-40639 Updated Release matrix

### Fixed
- IIP-40631 Fixed installation of InfoScale 8.0.2 failure on RHEL 9

### Other
- None


## [2.8.0] - 2023-01-06
MD5 - 704725b5afee7a3292f1c7fbf450a8da

### Added
- IIP-38752 InfoScale Workflow for end-to-end VVR solution deployment
- IIP-38752, IIP-39393 Added vvr_solution role for end-to-end VVR deployment and required files like main.json (vars_file), yaml (infoscale_solution)
- IIP-40405 InfoScale 8.0.2 support on RHEL9

### Changed
- IIP-39572 Added support of FQDN/IP to systems parameter for VCS/SFHA/SFCFSHA UDP and TCP link configuration
- IIP-40396 Supporting private IP for onenode CP server
- IIP-39493 In configuration playbooks cluster_uuid is optional parameter
- IIP-40402 Updated release matrix

### Fixed
- IIP-40392 SF configuration Fix (EO Logging)
- IIP-40310 Fixed Rest Server configuration for default option
- IIP-40395 Fixed RouteConfig playbook for incorrect gateway value fetched
- IIP-39659 Fixed overlayIP issues for VVR configuration
- IIP-40429 Fix for get_tunables exception in module site-facters
- IIP-40449 Fixed issues encountered during VVR Automation 

### Other
- IIP-40375 get tunables code refactored change to class linuxproduct (undocumented)
- IIP-40418 Added a check to return when unconfiguring fencing on SFCFSHA configured cluster. SFCFSHA requires at least disabled fencing. Unconfiguring fencing is not a valid option.


## [2.7.0] - 2022-12-02
MD5 - 6abf46d30b6ae0b646fdf1470d9d19ac

### Added
- IIP-40137 Added the feature to set vcs, vxvm and vxfs tunables
- IIP-38560 Added support to set route and rules for subnet across availability zones on AWS
- IIP- 40138 Added support to get all the changed (not default) vcs, vxvm and vxfs tunables 

### Changed
- IIP-39876 Updated Release matrix

### Fixed                
- IIP-39645 Fixed multiple product patches on target nodes while installing InfoScale
- IIP-39897 Secure Cluster configuration fixes for AWS 

### Other
-None


## [2.6.1] - 2022-11-02
MD5 - 9e431fd1c3e49fc58b7b5a29d5d511dc 

### Added
- None

### Changed
- IIP-38772 Added EO Logging options for component configurations to enable and disable EO compliant logging
- IIP-39876 Updated Release matrix

### Fixed
- IIP-39750 GCO configuration fix for AWS - added AWSIP resource for VIP
- IIP-39658 VVR fixes for Azure - added azureAuth and azureIP resources for VIP
- IIP-39735 AWS_CLI fix needed for AWS platform

### Other
- None


## [2.6.0] - 2022-09-30
MD5 - 66f70b5692efec7c30c9fe2bf754865c

### Added
- IIP-39404 Provide support to enable and disable EO Logging

### Changed
- IIP-39494 Remove Passwordless SSH as the pre-requisite for Secure Cluster
- IIP-39643 Updated Release matrix 

### Fixed
- IIP-39276 Patch upgradation with InfoScale configured product 
- STESC-7352 InfoScale 7.4.1 for RHEL 8.6 Python 2.6
- IIP-39540 CVR configuration for 2 node primary and 2 node secondary site for Azure platform
- IIP-39547 Secondary could not get information about VVR setup due to timeout
- IIP-39522 GCO configuration fails on Azure for 2 node primary and 2 node secondary site

### Other
- IIP-39405 Enabled CVR for 2 node primary and 2 node secondary site on Azure


## [2.5.1] - 2022-09-02
MD5 - 3cb7a29cbf906fbe4958ce2df4b471f2

### Added
- IIP-37954 Display message and documentation link for using AWS agents since AWS CLI must be installed and configured on AWS machines.

### Changed
- IIP-39017+IIP-38803 Updating cloud identification to also support containerized environment
- IIP-39363 Seednode is optional and enabled support for FQDN/IP for start and stop service playbooks
- IIP-39361 Seednode is optional for secure cluster playbook
- IIP-39468 Updated release matrix

### Fixed
- IIP-38122 Race condition fix for secure cluster playbook      
- IIP-39485 Fixed VIP configuration playbook to avoid VIP configuration failure on provided NIC



## [2.5.0] - 2022-08-01

### Added
- IIP-38642 Added support to single private link on cloud (LLT/UDP)
- IIP-38674 Added support for deletion of master node and multiple nodes

### Changed
- IIP-38396 Added an option to create unformatted volume

### Fixed
